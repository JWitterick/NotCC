﻿namespace MathTestApp
{
    partial class Window
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Textbox = new System.Windows.Forms.TextBox();
            this.OptionA = new System.Windows.Forms.RadioButton();
            this.OptionB = new System.Windows.Forms.RadioButton();
            this.OptionC = new System.Windows.Forms.RadioButton();
            this.OptionD = new System.Windows.Forms.RadioButton();
            this.ProgressBar = new System.Windows.Forms.ProgressBar();
            this.Submit = new System.Windows.Forms.Button();
            this.AnsserBox = new System.Windows.Forms.TextBox();
            this.Results = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Textbox
            // 
            this.Textbox.AcceptsReturn = true;
            this.Textbox.Location = new System.Drawing.Point(12, 12);
            this.Textbox.Multiline = true;
            this.Textbox.Name = "Textbox";
            this.Textbox.ReadOnly = true;
            this.Textbox.Size = new System.Drawing.Size(339, 77);
            this.Textbox.TabIndex = 0;
            this.Textbox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // OptionA
            // 
            this.OptionA.AutoSize = true;
            this.OptionA.Location = new System.Drawing.Point(12, 95);
            this.OptionA.Name = "OptionA";
            this.OptionA.Size = new System.Drawing.Size(164, 34);
            this.OptionA.TabIndex = 1;
            this.OptionA.TabStop = true;
            this.OptionA.Text = "radioButton1";
            this.OptionA.UseVisualStyleBackColor = true;
            // 
            // OptionB
            // 
            this.OptionB.AutoSize = true;
            this.OptionB.Location = new System.Drawing.Point(187, 95);
            this.OptionB.Name = "OptionB";
            this.OptionB.Size = new System.Drawing.Size(164, 34);
            this.OptionB.TabIndex = 2;
            this.OptionB.TabStop = true;
            this.OptionB.Text = "radioButton1";
            this.OptionB.UseVisualStyleBackColor = true;
            // 
            // OptionC
            // 
            this.OptionC.AutoSize = true;
            this.OptionC.Location = new System.Drawing.Point(12, 135);
            this.OptionC.Name = "OptionC";
            this.OptionC.Size = new System.Drawing.Size(164, 34);
            this.OptionC.TabIndex = 3;
            this.OptionC.TabStop = true;
            this.OptionC.Text = "radioButton1";
            this.OptionC.UseVisualStyleBackColor = true;
            // 
            // OptionD
            // 
            this.OptionD.AutoSize = true;
            this.OptionD.Location = new System.Drawing.Point(187, 135);
            this.OptionD.Name = "OptionD";
            this.OptionD.Size = new System.Drawing.Size(164, 34);
            this.OptionD.TabIndex = 4;
            this.OptionD.TabStop = true;
            this.OptionD.Text = "radioButton2";
            this.OptionD.UseVisualStyleBackColor = true;
            // 
            // ProgressBar
            // 
            this.ProgressBar.Location = new System.Drawing.Point(12, 215);
            this.ProgressBar.Maximum = 0;
            this.ProgressBar.Name = "ProgressBar";
            this.ProgressBar.Size = new System.Drawing.Size(339, 14);
            this.ProgressBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.ProgressBar.TabIndex = 5;
            // 
            // Submit
            // 
            this.Submit.Location = new System.Drawing.Point(12, 175);
            this.Submit.Name = "Submit";
            this.Submit.Size = new System.Drawing.Size(339, 34);
            this.Submit.TabIndex = 6;
            this.Submit.Text = "Submit";
            this.Submit.UseVisualStyleBackColor = true;
            this.Submit.Click += new System.EventHandler(this.Submit_Click);
            // 
            // AnsserBox
            // 
            this.AnsserBox.Location = new System.Drawing.Point(104, 114);
            this.AnsserBox.Name = "AnsserBox";
            this.AnsserBox.Size = new System.Drawing.Size(162, 37);
            this.AnsserBox.TabIndex = 7;
            // 
            // Results
            // 
            this.Results.AcceptsReturn = true;
            this.Results.AcceptsTab = true;
            this.Results.Location = new System.Drawing.Point(12, 12);
            this.Results.Multiline = true;
            this.Results.Name = "Results";
            this.Results.ReadOnly = true;
            this.Results.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.Results.Size = new System.Drawing.Size(339, 197);
            this.Results.TabIndex = 8;
            this.Results.Text = "--- Results ---";
            this.Results.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.Results.WordWrap = false;
            // 
            // Window
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 30F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(363, 236);
            this.Controls.Add(this.Results);
            this.Controls.Add(this.AnsserBox);
            this.Controls.Add(this.Submit);
            this.Controls.Add(this.ProgressBar);
            this.Controls.Add(this.OptionD);
            this.Controls.Add(this.OptionC);
            this.Controls.Add(this.OptionB);
            this.Controls.Add(this.OptionA);
            this.Controls.Add(this.Textbox);
            this.Name = "Window";
            this.Text = "Math test";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox Textbox;
        private RadioButton OptionA;
        private RadioButton OptionB;
        private RadioButton OptionC;
        private RadioButton OptionD;
        private ProgressBar ProgressBar;
        private Button Submit;
        private TextBox AnsserBox;
        private TextBox Results;
    }
}