using System.Threading;
namespace MathTestApp
{
    public partial class Window : Form
    {
        List<string> results = new List<string>();
        decimal answer = 1;
        public Window()
        {
            InitializeComponent();
            ShowShortAnser();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Textbox.Text = "How Many Questions?";
            Results.Visible = false;
        }

        private int tryconvert(string input)
        {
            try
            {
                return (Convert.ToInt32(input));
            }
            catch
            {
                return 0;
            }
        }
        private void ShowShortAnser()
        {
            OptionA.Visible = false;
            OptionB.Visible = false;
            OptionC.Visible = false;
            OptionD.Visible = false;
            AnsserBox.Visible = true;
        }
        private void ShowMultapuleChoice()
        {
            OptionA.Visible = true;
            OptionA.Text = "";
            OptionA.Checked = false;
            OptionB.Visible = true;
            OptionB.Text = "";
            OptionB.Checked = false;
            OptionC.Visible = true;
            OptionC.Text = "";
            OptionC.Checked = false;
            OptionD.Visible = true;
            OptionD.Text = "";
            OptionD.Checked = false;
            AnsserBox.Visible = false;
        }
        private void Submit_Click(object sender, EventArgs e)
        {
            if (Submit.Text == "Submit")
            {
                if (ProgressBar.Maximum == 0)
                {
                    try
                    {
                        if (Convert.ToInt32(AnsserBox.Text) == 0)
                            TryAgain("0 is not a option");
                        else 
                        {
                            ProgressBar.Maximum = (Convert.ToInt32(AnsserBox.Text));
                            Genarate();
                        }
                    }
                    catch
                    {
                        TryAgain("Please input a number");
                        AnsserBox.Text = "";
                    }
                }
                else
                {
                    try
                    {
                        if (AnsserBox.Visible == true)
                        {
                            if (AnsserBox.Text != "")
                                Check(Convert.ToDecimal(AnsserBox.Text));
                            else
                                TryAgain("Please provide an awnser");
                        }
                        else
                        {
                            if (OptionA.Checked == true)
                                Check(Convert.ToDecimal(OptionA.Text));
                            else if (OptionB.Checked == true)
                                Check(Convert.ToDecimal(OptionB.Text));
                            else if (OptionC.Checked == true)
                                Check(Convert.ToDecimal(OptionC.Text));
                            else if (OptionD.Checked == true)
                                Check(Convert.ToDecimal(OptionD.Text));
                            else
                                TryAgain("Please select an answer");
                        }
                    }
                    catch
                    {
                        TryAgain("Stop what you are doing");
                    }
                }
            }
        }
        private async void TryAgain(string mesage)
        {
            Submit.Text = mesage;
            AnsserBox.Text = "";
            await Task.Delay(1000);
            Submit.Text = "Submit";
        }
        private async void Check(decimal Response)
        {
            if (Response == answer)
            {
                Submit.Text = "Corect";
                await Task.Delay(1000);
            }
            else
            {
                Submit.Text = "Incorect";
                await Task.Delay(1000);
            }
            ProgressBar.Value = ProgressBar.Value + 1;
            results.Add(Textbox.Lines[0] + " = " + Convert.ToString(answer) + "   " + Submit.Text);
            Submit.Text = "Submit";
            if (ProgressBar.Value == ProgressBar.Maximum)
            {
                int ir = results.Count;
                for (int i = ir; i > 0; i--)
                        Results.AppendText(Environment.NewLine + results[i - 1].ToString());
                Results.Visible = true;
            }
            else
                Genarate();
        }
        private void Genarate()
        {
            Random random = new Random();
            int rawOparator = random.Next(4);
            int IsShortAnswer = random.Next(2);
            decimal Number1 = random.Next(100);
            decimal Number2 = random.Next(100);
            AnsserBox.Text = "";
            if (rawOparator == 0)
            {
                answer = Number1 + Number2;
                Textbox.Text = Number1 + " + " + Number2;
            }
            if (rawOparator == 1)
            {
                answer = Number1 - Number2;
                Textbox.Text = Number1 + " - " + Number2;
            }
            if (rawOparator == 2)
            {
                answer = Number2 * Number1;
                Textbox.Text = Number1 + " * " + Number2;
            }
            if (rawOparator == 3)
            {
                answer = Math.Round(Number1 / Number2, 2);
                Textbox.Text = "";
                Textbox.AppendText(Number1 + "/" + Number2 + Environment.NewLine + "(round to 2 decimal places)");
            }
            if (IsShortAnswer == 0)
            {
                ShowMultapuleChoice();
                int CorectOption = random.Next(5);
                int answerRange = 0;
                while (answerRange <= 4)
                    answerRange = random.Next(-50, 50);
                while (OptionA.Text == "")
                    OptionA.Text = GenerateOption(answerRange, rawOparator, CorectOption,1);
                while (OptionB.Text == "" | OptionB.Text == OptionA.Text)
                    OptionB.Text = GenerateOption(answerRange, rawOparator, CorectOption,2);
                while (OptionC.Text == "" | OptionC.Text == OptionA.Text | OptionC.Text == OptionB.Text)
                    OptionC.Text = GenerateOption(answerRange, rawOparator, CorectOption,3);
                while (OptionD.Text == "" | OptionD.Text == OptionA.Text | OptionD.Text == OptionB.Text | OptionD.Text == OptionC.Text)
                    OptionD.Text = GenerateOption(answerRange, rawOparator, CorectOption,4);
            }
            else
                ShowShortAnser();
        }
        private string GenerateOption(int answerRange, int rawOporator, int correctOption, int OptionNum)
        {
            Random random = new Random();
            decimal Return = answer;
            if (correctOption == OptionNum)
                return Convert.ToString(answer);
            else while (Return == answer) 
                    if (rawOporator != 3)
                        Return = (answer + random.Next(0 - answerRange, answerRange));
                    else
                        while (Return < 0| Return == answer)
                            Return = Math.Round(Convert.ToDecimal(answer) + (random.Next(0, 99) / 100m) + random.Next(0 - answerRange, answerRange),2);
            return Convert.ToString(Return);
        }
    }
}